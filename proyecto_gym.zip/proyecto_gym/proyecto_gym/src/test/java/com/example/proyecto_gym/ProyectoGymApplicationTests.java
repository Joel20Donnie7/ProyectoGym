package com.example.proyecto_gym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoGymApplicationTests {

    @Test
    void contextLoads() {
    }

}
