package com.example.proyecto_gym.repository;

import com.example.proyecto_gym.entity.ExercisePlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExercisePlanRepository extends JpaRepository<ExercisePlan, Long> {
}
