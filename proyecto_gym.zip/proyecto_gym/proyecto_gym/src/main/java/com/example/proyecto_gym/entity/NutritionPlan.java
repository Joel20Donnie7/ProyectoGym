package com.example.proyecto_gym.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "nutrition_plans")
public class NutritionPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String meal;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private int calories;

    @Column(nullable = false)
    private String timeOfDay;
}
