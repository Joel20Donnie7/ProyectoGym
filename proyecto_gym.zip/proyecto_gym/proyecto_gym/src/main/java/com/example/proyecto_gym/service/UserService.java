import com.example.proyecto_gym.entity.*;
import com.example.proyecto_gym.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ExercisePlanRepository exercisePlanRepository;

    @Autowired
    private NutritionPlanRepository nutritionPlanRepository;

    // Métodos CRUD básicos
    public List<User> findAll() {
        return userRepository.findAll();
    }

    public User findById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public User save(User user) {
        return userRepository.save(user);
    }

    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }

    // Métodos para manejar las relaciones
    public void assignRoleToUser(Long userId, Long roleId) {
        Optional<User> user = userRepository.findById(userId);
        Optional<Role> role = roleRepository.findById(roleId);
        if (user.isPresent() && role.isPresent()) {
            user.get().getRoles().add(role.get());
            userRepository.save(user.get());
        }
    }

    public void assignExercisePlanToUser(Long userId, Long exercisePlanId) {
        Optional<User> user = userRepository.findById(userId);
        Optional<ExercisePlan> exercisePlan = exercisePlanRepository.findById(exercisePlanId);
        if (user.isPresent() && exercisePlan.isPresent()) {
            user.get().getExercisePlans().add(exercisePlan.get());
            userRepository.save(user.get());
        }
    }

    public void assignNutritionPlanToUser(Long userId, Long nutritionPlanId) {
        Optional<User> user = userRepository.findById(userId);
        Optional<NutritionPlan> nutritionPlan = nutritionPlanRepository.findById(nutritionPlanId);
        if (user.isPresent() && nutritionPlan.isPresent()) {
            user.get().getNutritionPlans().add(nutritionPlan.get());
            userRepository.save(user.get());
        }
    }
}
