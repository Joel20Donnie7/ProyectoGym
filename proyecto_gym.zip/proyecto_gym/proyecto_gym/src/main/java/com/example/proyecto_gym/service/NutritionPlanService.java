package com.example.proyecto_gym.service;


import com.example.proyecto_gym.entity.NutritionPlan;
import com.example.proyecto_gym.repository.NutritionPlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NutritionPlanService {
    @Autowired
    private NutritionPlanRepository nutritionPlanRepository;

    public List<NutritionPlan> findAll() {
        return nutritionPlanRepository.findAll();
    }

    public NutritionPlan findById(Long id) {
        return nutritionPlanRepository.findById(id).orElse(null);
    }

    public NutritionPlan save(NutritionPlan nutritionPlan) {
        return nutritionPlanRepository.save(nutritionPlan);
    }

    public void deleteById(Long id) {
        nutritionPlanRepository.deleteById(id);
    }
}