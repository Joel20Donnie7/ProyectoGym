import com.example.proyecto_gym.entity.*;
import com.example.proyecto_gym.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ArticleService {
    @Autowired
    private ArticleRepository articleRepository;

    @Autowired
    private RecommendationRepository recommendationRepository;

    @Autowired
    private ResourceRepository resourceRepository;

    // CRUD básico
    public List<Article> findAll() {
        return articleRepository.findAll();
    }

    public Article findById(Long id) {
        return articleRepository.findById(id).orElse(null);
    }

    public Article save(Article article) {
        return articleRepository.save(article);
    }

    public void deleteById(Long id) {
        articleRepository.deleteById(id);
    }

    // Métodos para manejar relaciones
    public void addRecommendationToArticle(Long articleId, Recommendation recommendation) {
        Optional<Article> article = articleRepository.findById(articleId);
        if (article.isPresent()) {
            recommendation.setArticle(article.get());
            recommendationRepository.save(recommendation);
        }
    }

    public void addResourceToArticle(Long articleId, Resource resource) {
        Optional<Article> article = articleRepository.findById(articleId);
        if (article.isPresent()) {
            resource.setArticle(article.get());
            resourceRepository.save(resource);
        }
    }
}
