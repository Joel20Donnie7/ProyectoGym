package com.example.proyecto_gym.service;

import com.example.proyecto_gym.entity.ExercisePlan;
import com.example.proyecto_gym.repository.ExercisePlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExercisePlanService {
    @Autowired
    private ExercisePlanRepository exercisePlanRepository;

    public List<ExercisePlan> findAll() {
        return exercisePlanRepository.findAll();
    }

    public ExercisePlan findById(Long id) {
        return exercisePlanRepository.findById(id).orElse(null);
    }

    public ExercisePlan save(ExercisePlan exercisePlan) {
        return exercisePlanRepository.save(exercisePlan);
    }

    public void deleteById(Long id) {
        exercisePlanRepository.deleteById(id);
    }
}