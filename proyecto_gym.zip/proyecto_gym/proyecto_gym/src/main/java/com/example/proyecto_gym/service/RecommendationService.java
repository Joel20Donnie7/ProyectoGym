package com.example.proyecto_gym.service;

import com.example.proyecto_gym.entity.Recommendation;
import com.example.proyecto_gym.repository.RecommendationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecommendationService {
    @Autowired
    private RecommendationRepository recommendationRepository;

    public List<Recommendation> findAll() {
        return recommendationRepository.findAll();
    }

    public Recommendation findById(Long id) {
        return recommendationRepository.findById(id).orElse(null);
    }

    public Recommendation save(Recommendation recommendation) {
        return recommendationRepository.save(recommendation);
    }

    public void deleteById(Long id) {
        recommendationRepository.deleteById(id);
    }
}
