package com.example.proyecto_gym.controller;

import com.example.proyecto_gym.entity.NutritionPlan;
import com.example.proyecto_gym.service.NutritionPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/nutrition-plans")
public class NutritionPlanController {
    @Autowired
    private NutritionPlanService nutritionPlanService;

    @GetMapping
    public String listAll(Model model) {
        List<NutritionPlan> nutritionPlans = nutritionPlanService.findAll();
        model.addAttribute("nutritionPlans", nutritionPlans);
        return "nutrition-plans/index";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("nutritionPlan", new NutritionPlan());
        return "nutrition-plans/create";
    }

    @PostMapping
    public String create(@ModelAttribute NutritionPlan nutritionPlan) {
        nutritionPlanService.save(nutritionPlan);
        return "redirect:/nutrition-plans";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        NutritionPlan nutritionPlan = nutritionPlanService.findById(id);
        model.addAttribute("nutritionPlan", nutritionPlan);
        return "nutrition-plans/edit";
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, @ModelAttribute NutritionPlan nutritionPlan) {
        nutritionPlan.setId(id);
        nutritionPlanService.save(nutritionPlan);
        return "redirect:/nutrition-plans";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        nutritionPlanService.deleteById(id);
        return "redirect:/nutrition-plans";
    }
}
