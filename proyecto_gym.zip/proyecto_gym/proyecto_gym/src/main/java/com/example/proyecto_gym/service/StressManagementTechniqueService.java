package com.example.proyecto_gym.service;


import com.example.proyecto_gym.entity.StressManagementTechnique;
import com.example.proyecto_gym.repository.StressManagementTechniqueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StressManagementTechniqueService {
    @Autowired
    private StressManagementTechniqueRepository stressManagementTechniqueRepository;

    public List<StressManagementTechnique> findAll() {
        return stressManagementTechniqueRepository.findAll();
    }

    public StressManagementTechnique findById(Long id) {
        return stressManagementTechniqueRepository.findById(id).orElse(null);
    }

    public StressManagementTechnique save(StressManagementTechnique stressManagementTechnique) {
        return stressManagementTechniqueRepository.save(stressManagementTechnique);
    }

    public void deleteById(Long id) {
        stressManagementTechniqueRepository.deleteById(id);
    }
}