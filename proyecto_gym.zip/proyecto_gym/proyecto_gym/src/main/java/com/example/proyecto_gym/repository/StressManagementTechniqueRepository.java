package com.example.proyecto_gym.repository;

import com.example.proyecto_gym.entity.StressManagementTechnique;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StressManagementTechniqueRepository extends JpaRepository<StressManagementTechnique, Long> {
}