package com.example.proyecto_gym.repository;

import com.example.proyecto_gym.entity.Recommendation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecommendationRepository extends JpaRepository<Recommendation, Long> {
}