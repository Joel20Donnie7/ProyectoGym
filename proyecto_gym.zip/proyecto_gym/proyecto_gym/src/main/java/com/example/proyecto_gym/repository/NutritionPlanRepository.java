package com.example.proyecto_gym.repository;

import com.example.proyecto_gym.entity.NutritionPlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NutritionPlanRepository extends JpaRepository<NutritionPlan, Long> {
}