package com.example.proyecto_gym.service;

import com.example.proyecto_gym.entity.UserRole;
import com.example.proyecto_gym.entity.UserRoleId;
import com.example.proyecto_gym.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserRoleService {
    @Autowired
    private UserRoleRepository userRoleRepository;

    public List<UserRole> findAll() {
        return userRoleRepository.findAll();
    }

    public UserRole findById(Long userId, Long roleId) {
        return userRoleRepository.findById(new UserRoleId(userId, roleId)).orElse(null);
    }

    public UserRole save(UserRole userRole) {
        return userRoleRepository.save(userRole);
    }

    public void deleteById(Long userId, Long roleId) {
        userRoleRepository.deleteById(new UserRoleId(userId, roleId));
    }
}