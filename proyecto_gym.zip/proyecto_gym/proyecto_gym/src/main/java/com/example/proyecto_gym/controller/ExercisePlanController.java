package com.example.proyecto_gym.controller;

import com.example.proyecto_gym.entity.ExercisePlan;
import com.example.proyecto_gym.service.ExercisePlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/exercise-plans")
public class ExercisePlanController {

    @Autowired
    private ExercisePlanService exercisePlanService;

    @GetMapping
    public String listAll(Model model) {
        List<ExercisePlan> exercisePlans = exercisePlanService.findAll();
        model.addAttribute("exercisePlans", exercisePlans);
        return "exercise-plans/index"; // Lista general
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("exercisePlan", new ExercisePlan());
        return "exercise-plans/create"; // Formulario para crear
    }

    @PostMapping("/create")
    public String create(@ModelAttribute("exercisePlan") ExercisePlan exercisePlan, BindingResult result) {
        if (result.hasErrors()) {
            return "exercise-plans/create"; // Return to form if there are errors
        }
        exercisePlanService.save(exercisePlan);
        return "redirect:/exercise-plans"; // Redirect after creation
    }


    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        ExercisePlan exercisePlan = exercisePlanService.findById(id);
        if (exercisePlan == null) {
            return "redirect:/exercise-plans"; // Redirigir si no existe
        }
        model.addAttribute("exercisePlan", exercisePlan);
        return "exercise-plans/edit"; // Formulario de edición
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, @ModelAttribute("exercisePlan") ExercisePlan exercisePlan) {
        exercisePlan.setId(id);
        exercisePlanService.save(exercisePlan);
        return "redirect:/exercise-plans"; // Redirigir después de actualizar
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        exercisePlanService.deleteById(id);
        return "redirect:/exercise-plans"; // Redirigir después de eliminar
    }

    @GetMapping("/list")
    public String listExercisePlans(Model model) {
        List<ExercisePlan> exercisePlans = exercisePlanService.findAll();
        model.addAttribute("exercisePlans", exercisePlans);
        return "exercise-plans/list"; // Vista en formato tabla
    }
}
