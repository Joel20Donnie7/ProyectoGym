package com.example.proyecto_gym.repository;

import com.example.proyecto_gym.entity.UserRole;
import com.example.proyecto_gym.entity.UserRoleId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRoleRepository extends JpaRepository<UserRole, UserRoleId> {
    Optional<UserRole> findById(UserRoleId userRoleId);
}
