package com.example.proyecto_gym.repository;

import com.example.proyecto_gym.entity.Article;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArticleRepository extends JpaRepository<Article, Long> {
}